<?php


namespace App\Controllers;

class Chatbot extends BaseController
{


    // ======== CHAT BOT MSG VIEW =====
    public function index()
    {
        $data =  [
            "title" => "Adiana-ChatBot"
        ];

        return view('chatbot/index', $data);
    }

    public function Admin()
    {
        $data = [
            'title' => 'Admin-ChatBot'
        ];

        return view('Admin/dashboard', $data);
    }
}
