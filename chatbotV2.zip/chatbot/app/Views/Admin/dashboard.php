 <?= $this->extend('layout/template'); ?>
 <?= $this->section('content'); ?>


 <!-- ========= CHAT CONTENT ======= -->
 <div class="box-chat-content bg-light">

     <?php for ($i = 0; $i <= 10; $i++) : ?>
         <!-- USER CHAT -->
         <div class="chat-user bg-primary ml-1 mb-2 mt-3 text-light">
             <p>Hallo min Mau nanya pendaftaran kapan dibuka ya min?</p>
         </div>

         <!-- BOT CHAT -->
         <div class="chat-bot bg-dark ml-auto text-light">
             <p>
                 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga quod repellat voluptatum error perspiciatis! Atque nostrum quae maiores quisquam vero? Aspernatur dolorem et at hic? </p>
         </div>

     <?php endfor; ?>

 </div>

 <!-- ========= FORM INPUT CONTENT ====== -->
 <div class="input-content">
     <form action="">
         <div class="row justify-content-center">
             <div class="col-md ">
                 <i class="fas fa-smile-beam mr-3"></i>
                 <textarea name="msg-admin" id=""></textarea>

                 <i class="fas fa-paper-plane ml-3"></i>
             </div>

         </div>
     </form>
 </div>

 <?= $this->endSection(); ?>