<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <!-- ======= FONT AWESOME ====== -->
    <link href="<?= base_url() ?>/vendor/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- ====== STYLE CSS ==========-->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/chat.css">

    <!-- ===== RESPONSIVE CSS ===== -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/css/responsive.css">

    <!-- ======== JQUERY ======= -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <title><?= $title; ?></title>
</head>

<body>

    <!-- ======= CHAT BOT ======== -->
    <div class="chat-bot">


        <!-- ======= HEADER MSG ======= -->
        <div class="msg-header bg-warning ">
            <div class="close-button ml-auto" title="Close">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="msg-header-img">
                <img src="<?= base_url(); ?>/assets/img/profil.jpeg" alt="">
                <strong>Adiana Chat Bot</strong>

            </div>
        </div>


        <!-- ======= MSG BOX -->
        <div class="msg-box">


            <?php for ($i = 0; $i <= 10; $i++) : ?>
                <!-- === MSG BOT ===== -->
                <div class="msg-bot bg-primary text-light mt-2 ml-1 mb-3">
                    <p>Hidup ini adalah kesempoatan yang tidak bisa di
                        lihat oleh semua org karena ini ialah hidup yang tidak berguna karna ini
                    </p>
                </div>


                <!-- ========= MSG USER ======= -->
                <div class="msg-user bg-dark text-light mt-2 ml-auto mb-3 mr-1">
                    <p>hy</p>
                </div>
            <?php endfor; ?>

        </div>
        <!-- ===== FORM INPUT PESAN ====== -->
        <div class="form-input ml-3 mt-1 ">
            <form action="" method="POST">

                <div class="row">
                    <div class="col-md">
                        <div class="border-textrea">
                            <textarea id="form-input" name="msg_user" cols="40" rows="5"></textarea>
                        </div>
                    </div>

                    <div class="col-md btn-send mt-1">
                        <button type="submit" class="">

                            <i class="fas fa-paper-plane"></i>

                        </button>

                    </div>
                </div>

                <!-- <in id="form-input" type="text" name="msg_user" autocomplete="off"> -->

            </form>
        </div>

    </div>
    <!-- ======= END CHATBOT ====== -->

    <!-- ====== CHAT BOT ICON ======= -->

    <div class="chat-icon">
        <span>
            <i class="far fa-comments"></i>
        </span>
    </div>


    <!-- ======= END CHAT BOT ICON ======= -->









    <!--======= SCRIPT JS ======== -->
    <script>
        $('document').ready(function() {

            $('.chat-icon').click(function() {
                $('.chat-bot').toggleClass('active');


            });

            $('.close-button').on('click', function() {
                $('.chat-bot').toggleClass('active');
            });



        });
    </script>








    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
    -->
</body>

</html>