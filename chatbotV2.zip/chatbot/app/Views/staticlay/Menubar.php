<div class="bar-icon bg-dark text-light icon-size ">
    <div class="row">
        <div class="col-lg">
            <span>
                <i class="fas fa-audio-description">
                </i>
            </span>

        </div>
    </div>
    <div class="row icon-position">
        <div class="col-lg">
            <i class="fas fa-comment-alt">
                <span class="badge badge-danger badge-icon ">9</span>
            </i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fas fa-globe-asia">
                <span class="badge badge-danger badge-icon">9</span>

            </i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fas fa-user-tie"></i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fas fa-paper-plane"></i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fas fa-sticky-note"></i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fab fa-dropbox"></i>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-lg">
            <i class="fas fa-cog">

            </i>

        </div>
    </div>

</div>