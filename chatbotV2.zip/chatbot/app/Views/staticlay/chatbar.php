<!-- =========== HEADER NAVBAR NOTIF ======== -->
<div class="row">
    <div class="col-lg">
        <ul>
            <li>
                <a href="">
                    All
                </a>
            </li>

            <li>
                <a href="">
                    Unread
                </a>
            </li>

            <li>
                <a href="">
                    Unresolved
                </a>
            </li>
            <li class="dropdown">
                <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Filters
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Another action</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </li>
        </ul>
    </div>


</div>



<!-- ========== NOTIF CHAT ======== -->

<div class="row">
    <div class="box-notif">
        <?php $i = 1; ?>
        <?php for ($i = 0; $i <= 10; $i++) : ?>
            <div class="row">
                <div class="col-md">

                    <!-- ======= CHAT UNREAD ======= -->
                    <div class="card w-100 bg-light">
                        <div class="row">
                            <div class="col-md-1 mt-4 ">
                                <div class="card-logo ml-2">
                                    <i class="fas fa-user-circle "></i>
                                </div>
                            </div>


                            <div class="col-md-9">
                                <div class="card-body">
                                    <h5 class="card-title">User <span class="badge badge-success "><?= $i; ?></span></h5>
                                    <p class="card-text">Kapan Pendaftaran dibuka min ?</p>

                                </div>
                            </div>
                            <div class="col-md-2 mt-4">
                                <p style="font-size: 13px;">1 Nov</p>
                                <i class="fas fa-arrow-right text-primary"></i>
                            </div>
                        </div>
                    </div>

                    <!-- ========= END CHAT UNREAD ===== -->
                    <!-- ========= CHAT READ ========= -->

                    <div class="card w-100">
                        <div class="row">
                            <div class="col-md-1 mt-4 ">
                                <div class="card-logo ml-2">
                                    <i class="fas fa-user-circle "></i>
                                </div>
                            </div>


                            <div class="col-md-11">
                                <div class="card-body">
                                    <h5 class="card-title">User <?= $i; ?></h5>
                                    <p class="card-text">Kapan Pendaftaran dibuka min ?</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- ======== END CHAT READ ========== -->

                </div>

            </div>
        <?php endfor; ?>


    </div>
</div>