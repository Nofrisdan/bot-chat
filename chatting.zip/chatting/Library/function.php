<?php
// koneksi ke database

$host = 'localhost';
$user = 'nofrisdan';
$pass = 'N03D0600';
$db = 'bot';



$connect = mysqli_connect($host, $user, $pass, $db);

//cek jika koneksi ke database gagal
// if(mysqli_connect_error()){
//     echo "Gagal melakukan koneksi ke MySQL: " .mysqli_connect_error();
// }


// NGambil data
function query($query)
{
    global $connect;
    $result = mysqli_query($connect, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

// insert data

function insert($data)
{
    global $connect;
    $pertanyaan = $data['pertanyaan'];
    $jawaban = $data['jawaban'];


    $query = "INSERT INTO chatbot VALUES (null,'$pertanyaan','$jawaban')";
    // insert db
    mysqli_query($connect, $query);

    return mysqli_affected_rows($connect);
}

function delete($id)
{
    global $connect;
    mysqli_query($connect, "DELETE FROM chatbot WHERE id = $id");

    return mysqli_affected_rows($connect);
}

// edit

function edit($data)
{
    global $connect;
    $id = $data['id'];
    $pertanyaan = $data['pertanyaan'];
    $jawaban = $data['jawaban'];
    mysqli_query($connect, "UPDATE chatbot SET pertanyaan='$pertanyaan',jawaban='$jawaban' WHERE id=$id");

    return mysqli_affected_rows($connect);
}
