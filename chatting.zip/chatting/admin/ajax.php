<?php


require '../Library/function.php';
// var_dump($jsonFile);
if(isset($_GET['idData'])){
    $id = $_GET['idData'];
    $data = query("SELECT * FROM chatbot WHERE id = $id")[0];


    $jsonFile = json_encode($data,JSON_PRETTY_PRINT);

    echo $jsonFile;
}