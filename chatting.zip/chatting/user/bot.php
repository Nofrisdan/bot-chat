<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="style1.css">
    <title>Chatbot PMB</title>
</head>

<body>

    <div id="utama" class="icon-utama">
        <img src="img/bot.png" alt="">
    </div>

    <div id="content" class="wrapper">
        <div class="title">
            <div class="icon-gbr">
                <img src="img/bot.png" alt="">  
            </div>
              
            <h1>Adiana</h1>

            <div class="exit">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="white" class="bi bi-x" viewBox="0 0 16 16" >
                <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
            </svg>
            </div> 
        </div>
       
        <div class="form">
            <div class="bot-inbox inbox">
                <div class="icon">
                    <img src="img/bot.png" alt="">
                </div>
                <div class="msg-header">
                    <p>Halo, aku Adiana, asisten virtual kamu. Kalau ada pertanyaan tentang Penerimaan Mahasiswa Baru (PMB), Adiana bisa bantu.</p>
                </div>
            </div>
        </div>

        <div class="typing-field">
            <div class="input-data">
                <input id="data" type="text" placeholder="Ketik pesan..." required>
                <button id="send-btn">Send</button>
            </div>
        </div>
    </div>


<!-- jquery -->
    <script
    src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous">
    </script>

   <script>
       $(document).ready(function(){
           $("#send-btn").on("click", function(){
                $value = $("#data").val();
                $msg = '<div class="user-inbox inbox"><div class="msg-header"><p>'+$value+'</p></div></div>';
                $(".form").append($msg);
                $("#data").val('');

                // start ajax code
                $.ajax({
                    url: 'message.php',
                    type: 'POST',
                    data: 'text='+$value,
                    success: function(result){
                        $replay = '<div class="bot-inbox inbox"><div class="icon"><img src="img/bot.png" alt=""></div><div class="msg-header"><p>'+result+'</p></div></div>'
                        $(".form").append($replay);
                        // untuk scroll chat secara otomatis ke bawah jika halamannya sudah full
                        $(".form").scrollTop($(".form")[0].scrollHeight);
                    }
                })
           });
        });

   </script>

<script src="script.js"></script>

   
</body>
</html>