<?php
    // conneting to database
    $conn = mysqli_connect("localhost", "root", "", "bot") or die("Database Error");

    // getting user message through ajax
    $getMesg = mysqli_real_escape_string($conn, $_POST['text']);

    // cheking user query
    $check_data = "SELECT answer From chatbot where question like '%$getMesg%'";
    $run_query = mysqli_query($conn, $check_data) or die("Error");

    // if user query matched to databse query we'll show the reply otherwise it go to else statement
    if(mysqli_num_rows($run_query) > 0){
        $fetch_data = mysqli_fetch_assoc($run_query);

        $replay = $fetch_data['answer'];

        echo $replay;
    }else{
        echo "Sorry ca't be able to understand you!";
    }
?>